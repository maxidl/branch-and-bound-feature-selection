# Branch-and-Bound-Feature-Selection-Python
Implementation of Feature Selection using Branch and Bound (Backward Elimination)
